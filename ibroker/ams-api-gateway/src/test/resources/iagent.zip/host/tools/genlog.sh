#!/bin/sh

path=`dirname $0`
cd $path
# base=`pwd`
# gateway=`basename $base`

# we should find a better to find pid for applications
#
apps="gateway_mgr gw_broker z-agent"
echo genlog.sh for $apps

for app in $apps
do
	appid=`pidof $app`
	if  [ -n "$appid" ] ;then
		echo "$app process id is $appid, send SIGUSR2(12) to generate log!"
		kill -12 $appid
	else
		echo "$app process id not found!"
	fi
done

