#!/bin/bash


SCRIPT=$(readlink -f "$0")
# Absolute path this script is in, thus /home/user/bin
SCRIPTPATH=$(dirname "$SCRIPT")

base=$(readlink -f $SCRIPTPATH/../../)
gateway=`basename $base`

echo "Try to upload logs under $base ..."

log_server=`cat $base/product/logcfg.ini | grep log_server | tr -d "\r" | sed 's/=/ /g' | awk '{print $2}'`
logs_root=`cat $base/product/logcfg.ini | grep path | tr -d "\r" | sed 's/=/ /g' | awk '{print $2}'`
if  [ ! -n "$log_server" ] ;then
	echo Log server name not configured in logcfg.ini
	exit
fi

if  [ ! -d "$base/config/device/ssh/$log_server" ] ;then
	echo Log server ssh folder [$base/config/device/ssh/$log_server] is not available
	exit
fi
if  [ ! -f "$base/config/device/ssh/$log_server/ssh_config" ] ;then
echo Log server ssh_config file is not available
	exit
fi

server=`cat $base/config/device/ssh/$log_server/ssh_config | grep host | grep -v hostname | tr -d "\r" | awk '{print $2}'`
user=`cat $base/config/device/ssh/$log_server/ssh_config | grep user | tr -d "\r" | awk '{print $2}'`
remote=`cat $base/config/iagent.ini | grep myid | tr -d "\r" | sed 's/\"/ /g' | awk '{print $3}'`

if  [ ! -n "$server" ] ;then
	echo Server name not configured, check ssh_config!
	exit
fi
if  [ ! -n "$user" ] ;then
	echo User name not configured, check ssh_config!
	exit
fi
if  [ ! -n "$remote" ] ;then
	echo Unable get gateway uuid, check clients.lst!
	exit
fi
if  [ ! -n "$logs_root" ] ;then
	echo Remote logs path not set, check daemon.ini!
	exit
fi

ssh -F $base/config/device/ssh/$log_server/ssh_config -i $base/config/device/ssh/$log_server/id_rsa $user@$server mkdir -p $logs_root/${remote}

# must at logs folders where ls get file name only which will be used at cloud
cd $base/logs/closed
apps=`ls *.log`
for item in $apps
do
	echo push zipped $item to cloud
	tar -czf $item.tar.gz $item

	scp -F $base/config/device/ssh/$log_server/ssh_config -i $base/config/device/ssh/$log_server/id_rsa $item.tar.gz $user@$server:$logs_root/${remote}
	verify=`ssh -F $base/config/device/ssh/$log_server/ssh_config -i $base/config/device/ssh/$log_server/id_rsa $user@$server ls $logs_root/${remote}`
	if [ -n "$verify" ]; then
	  echo "upload success, delete local file [$item]"
	  rm -f $item
	fi
	rm -f $itm $item.tar.gz
done

