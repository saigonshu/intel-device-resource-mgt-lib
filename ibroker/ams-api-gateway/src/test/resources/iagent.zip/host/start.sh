#!/bin/bash

export LD_LIBRARY_PATH=lib
./gw_broker gw_broker_lin.json
